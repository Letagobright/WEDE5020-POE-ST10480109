// script.js
function toggleDetails(card) {
    const details = card.querySelector('.details');
    
    if (details.classList.contains('visible')) {
        details.classList.remove('visible');
    } else {
        // Hide any visible details on other cards
        const allDetails = document.querySelectorAll('.details');
        allDetails.forEach(detail => detail.classList.remove('visible'));

        // Show the clicked card's details
        details.classList.add('visible');
    }
}



function toggleDetails(productId) {
    var details = document.getElementById(productId);
    if (details.style.display === "none" || details.style.display === "") {
        details.style.display = "block";
    } else {
        details.style.display = "none";
    }
}
